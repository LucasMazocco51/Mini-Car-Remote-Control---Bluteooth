/*
 * mini_car_ble_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mini_car_ble".
 *
 * Model version              : 1.18
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Sat May 11 14:41:02 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_mini_car_ble_private_h_
#define RTW_HEADER_mini_car_ble_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "mini_car_ble.h"
#include "mini_car_ble_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmSetTFinal
#define rtmSetTFinal(rtm, val)         ((rtm)->Timing.tFinal = (val))
#endif

extern real_T look1_binlcpw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);
extern void mini_car_ble_IfActionSubsystem(real_T *rty_Out1,
  P_IfActionSubsystem_mini_car__T *localP);
extern void mini_car_ble_SpeedMode1(uint16_T *rty_Out1,
  P_SpeedMode1_mini_car_ble_T *localP);
extern void mini_car_ble_Frente(real_T *rty_IN1_RMotor, real_T *rty_IN2_RMotor,
  real_T *rty_IN3_LMotor, real_T *rty_IN4_LMotor, P_Frente_mini_car_ble_T
  *localP);

#endif                                 /* RTW_HEADER_mini_car_ble_private_h_ */
