/*
 * mini_car_ble_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mini_car_ble".
 *
 * Model version              : 1.17
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Sat May 11 03:00:30 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mini_car_ble.h"

/* Block parameters (default storage) */
P_mini_car_ble_T mini_car_ble_P = {
  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S26>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant_const_h
   * Referenced by: '<S29>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S30>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant2_const
   * Referenced by: '<S31>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant3_const
   * Referenced by: '<S32>/Constant'
   */
  0.0,

  /* Mask Parameter: CompareToConstant1_const_i
   * Referenced by: '<S14>/Constant'
   */
  0U,

  /* Mask Parameter: CompareToConstant2_const_c
   * Referenced by: '<S15>/Constant'
   */
  8U,

  /* Mask Parameter: CompareToConstant3_const_g
   * Referenced by: '<S16>/Constant'
   */
  2U,

  /* Mask Parameter: CompareToConstant4_const
   * Referenced by: '<S17>/Constant'
   */
  16U,

  /* Mask Parameter: CompareToConstant5_const
   * Referenced by: '<S18>/Constant'
   */
  1U,

  /* Mask Parameter: CompareToConstant6_const
   * Referenced by: '<S19>/Constant'
   */
  8U,

  /* Mask Parameter: CompareToConstant7_const
   * Referenced by: '<S20>/Constant'
   */
  3U,

  /* Mask Parameter: CompareToConstant8_const
   * Referenced by: '<S21>/Constant'
   */
  16U,

  /* Mask Parameter: CompareToConstant9_const
   * Referenced by: '<S22>/Constant'
   */
  2U,

  /* Mask Parameter: CompareToConstant_const_n
   * Referenced by: '<S5>/Constant'
   */
  1U,

  /* Mask Parameter: CompareToConstant1_const_n
   * Referenced by: '<S6>/Constant'
   */
  2U,

  /* Mask Parameter: CompareToConstant2_const_a
   * Referenced by: '<S7>/Constant'
   */
  3U,

  /* Mask Parameter: DetectChange_vinit
   * Referenced by: '<S8>/Delay Input1'
   */
  0U,

  /* Mask Parameter: CompareToConstant_const_a
   * Referenced by: '<S13>/Constant'
   */
  16U,

  /* Expression: 0
   * Referenced by: '<S28>/Constant'
   */
  0.0,

  /* Expression: [170, 170, 20, -170, 170]
   * Referenced by: '<S27>/Motor A'
   */
  { 170.0, 170.0, 20.0, -170.0, 170.0 },

  /* Expression: [5, 55, 95, 143, 200]
   * Referenced by: '<S27>/Motor A'
   */
  { 5.0, 55.0, 95.0, 143.0, 200.0 },

  /* Expression: [20, 170, 170, -170, 20]
   * Referenced by: '<S27>/Motor B'
   */
  { 20.0, 170.0, 170.0, -170.0, 20.0 },

  /* Expression: [5, 55, 95, 143, 200]
   * Referenced by: '<S27>/Motor B'
   */
  { 5.0, 55.0, 95.0, 143.0, 200.0 },

  /* Computed Parameter: Merge_InitialOutput
   * Referenced by: '<S2>/Merge'
   */
  0.0,

  /* Computed Parameter: Merge2_InitialOutput
   * Referenced by: '<S4>/Merge2'
   */
  0.0,

  /* Computed Parameter: Merge3_InitialOutput
   * Referenced by: '<S4>/Merge3'
   */
  0.0,

  /* Computed Parameter: Merge4_InitialOutput
   * Referenced by: '<S4>/Merge4'
   */
  0.0,

  /* Computed Parameter: Merge5_InitialOutput
   * Referenced by: '<S4>/Merge5'
   */
  0.0,

  /* Computed Parameter: Constant_Value_m
   * Referenced by: '<S12>/Constant'
   */
  0U,

  /* Computed Parameter: UnitDelay_InitialCondition
   * Referenced by: '<S12>/Unit Delay'
   */
  0U,

  /* Computed Parameter: Merge_InitialOutput_m
   * Referenced by: '<S12>/Merge'
   */
  0U,

  /* Start of '<S4>/Re' */
  {
    /* Expression: 0
     * Referenced by: '<S34>/Constant'
     */
    0.0,

    /* Expression: 1
     * Referenced by: '<S34>/Constant1'
     */
    1.0
  }
  ,

  /* End of '<S4>/Re' */

  /* Start of '<S4>/Frente' */
  {
    /* Expression: 1
     * Referenced by: '<S33>/Constant'
     */
    1.0,

    /* Expression: 0
     * Referenced by: '<S33>/Constant1'
     */
    0.0
  }
  ,

  /* End of '<S4>/Frente' */

  /* Start of '<S12>/Speed Mode 3' */
  {
    /* Computed Parameter: Constant_Value
     * Referenced by: '<S25>/Constant'
     */
    3U
  }
  ,

  /* End of '<S12>/Speed Mode 3' */

  /* Start of '<S12>/Speed Mode 2' */
  {
    /* Computed Parameter: Constant_Value
     * Referenced by: '<S24>/Constant'
     */
    2U
  }
  ,

  /* End of '<S12>/Speed Mode 2' */

  /* Start of '<S12>/Speed Mode 1' */
  {
    /* Computed Parameter: Constant_Value
     * Referenced by: '<S23>/Constant'
     */
    1U
  }
  ,

  /* End of '<S12>/Speed Mode 1' */

  /* Start of '<S2>/If Action Subsystem2' */
  {
    /* Expression: 3
     * Referenced by: '<S11>/Constant'
     */
    3.0
  }
  ,

  /* End of '<S2>/If Action Subsystem2' */

  /* Start of '<S2>/If Action Subsystem1' */
  {
    /* Expression: 2
     * Referenced by: '<S10>/Constant'
     */
    2.0
  }
  ,

  /* End of '<S2>/If Action Subsystem1' */

  /* Start of '<S2>/If Action Subsystem' */
  {
    /* Expression: 1
     * Referenced by: '<S9>/Constant'
     */
    1.0
  }
  /* End of '<S2>/If Action Subsystem' */
};
