/*
 * mini_car_ble.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mini_car_ble".
 *
 * Model version              : 1.17
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Sat May 11 03:00:30 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_mini_car_ble_h_
#define RTW_HEADER_mini_car_ble_h_
#ifndef mini_car_ble_COMMON_INCLUDES_
#define mini_car_ble_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* mini_car_ble_COMMON_INCLUDES_ */

#include "mini_car_ble_types.h"
#include <float.h>
#include <string.h>
#include <stddef.h>
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Merge;                        /* '<S2>/Merge' */
  real_T Merge2;                       /* '<S4>/Merge2' */
  real_T Merge3;                       /* '<S4>/Merge3' */
  real_T Merge4;                       /* '<S4>/Merge4' */
  real_T Merge5;                       /* '<S4>/Merge5' */
  uint16_T Merge_d;                    /* '<S12>/Merge' */
} B_mini_car_ble_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  uint16_T DelayInput1_DSTATE;         /* '<S8>/Delay Input1' */
  uint16_T UnitDelay_DSTATE;           /* '<S12>/Unit Delay' */
} DW_mini_car_ble_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  uint16_T rx_directionStatus;         /* '<Root>/rx_directionStatus' */
  uint16_T rx_set_speed;               /* '<Root>/rx_set_speed' */
} ExtU_mini_car_ble_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Drive_RMotor;                 /* '<Root>/Drive_RMotor' */
  real_T Drive_LMotor;                 /* '<Root>/Drive_LMotor' */
  real_T IN1_RMotor;                   /* '<Root>/IN1_RMotor' */
  real_T IN2_RMotor;                   /* '<Root>/IN2_RMotor' */
  real_T IN3_LMotor;                   /* '<Root>/IN3_LMotor' */
  real_T IN4_LMotor;                   /* '<Root>/IN4_LMotor' */
} ExtY_mini_car_ble_T;

/* Parameters for system: '<S2>/If Action Subsystem' */
struct P_IfActionSubsystem_mini_car__T_ {
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S9>/Constant'
                                        */
};

/* Parameters for system: '<S12>/Speed Mode 1' */
struct P_SpeedMode1_mini_car_ble_T_ {
  uint16_T Constant_Value;             /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S23>/Constant'
                                        */
};

/* Parameters for system: '<S4>/Frente' */
struct P_Frente_mini_car_ble_T_ {
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S33>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S33>/Constant1'
                                        */
};

/* Parameters (default storage) */
struct P_mini_car_ble_T_ {
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S26>/Constant'
                                       */
  real_T CompareToConstant_const_h; /* Mask Parameter: CompareToConstant_const_h
                                     * Referenced by: '<S29>/Constant'
                                     */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S30>/Constant'
                                      */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S31>/Constant'
                                      */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S32>/Constant'
                                      */
  uint16_T CompareToConstant1_const_i;
                                   /* Mask Parameter: CompareToConstant1_const_i
                                    * Referenced by: '<S14>/Constant'
                                    */
  uint16_T CompareToConstant2_const_c;
                                   /* Mask Parameter: CompareToConstant2_const_c
                                    * Referenced by: '<S15>/Constant'
                                    */
  uint16_T CompareToConstant3_const_g;
                                   /* Mask Parameter: CompareToConstant3_const_g
                                    * Referenced by: '<S16>/Constant'
                                    */
  uint16_T CompareToConstant4_const; /* Mask Parameter: CompareToConstant4_const
                                      * Referenced by: '<S17>/Constant'
                                      */
  uint16_T CompareToConstant5_const; /* Mask Parameter: CompareToConstant5_const
                                      * Referenced by: '<S18>/Constant'
                                      */
  uint16_T CompareToConstant6_const; /* Mask Parameter: CompareToConstant6_const
                                      * Referenced by: '<S19>/Constant'
                                      */
  uint16_T CompareToConstant7_const; /* Mask Parameter: CompareToConstant7_const
                                      * Referenced by: '<S20>/Constant'
                                      */
  uint16_T CompareToConstant8_const; /* Mask Parameter: CompareToConstant8_const
                                      * Referenced by: '<S21>/Constant'
                                      */
  uint16_T CompareToConstant9_const; /* Mask Parameter: CompareToConstant9_const
                                      * Referenced by: '<S22>/Constant'
                                      */
  uint16_T CompareToConstant_const_n;
                                    /* Mask Parameter: CompareToConstant_const_n
                                     * Referenced by: '<S5>/Constant'
                                     */
  uint16_T CompareToConstant1_const_n;
                                   /* Mask Parameter: CompareToConstant1_const_n
                                    * Referenced by: '<S6>/Constant'
                                    */
  uint16_T CompareToConstant2_const_a;
                                   /* Mask Parameter: CompareToConstant2_const_a
                                    * Referenced by: '<S7>/Constant'
                                    */
  uint16_T DetectChange_vinit;         /* Mask Parameter: DetectChange_vinit
                                        * Referenced by: '<S8>/Delay Input1'
                                        */
  uint8_T CompareToConstant_const_a;/* Mask Parameter: CompareToConstant_const_a
                                     * Referenced by: '<S13>/Constant'
                                     */
  real_T Constant_Value;               /* Expression: 0
                                        * Referenced by: '<S28>/Constant'
                                        */
  real_T MotorA_tableData[5];          /* Expression: [170, 170, 20, -170, 170]
                                        * Referenced by: '<S27>/Motor A'
                                        */
  real_T MotorA_bp01Data[5];           /* Expression: [5, 55, 95, 143, 200]
                                        * Referenced by: '<S27>/Motor A'
                                        */
  real_T MotorB_tableData[5];          /* Expression: [20, 170, 170, -170, 20]
                                        * Referenced by: '<S27>/Motor B'
                                        */
  real_T MotorB_bp01Data[5];           /* Expression: [5, 55, 95, 143, 200]
                                        * Referenced by: '<S27>/Motor B'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S2>/Merge'
                                       */
  real_T Merge2_InitialOutput;       /* Computed Parameter: Merge2_InitialOutput
                                      * Referenced by: '<S4>/Merge2'
                                      */
  real_T Merge3_InitialOutput;       /* Computed Parameter: Merge3_InitialOutput
                                      * Referenced by: '<S4>/Merge3'
                                      */
  real_T Merge4_InitialOutput;       /* Computed Parameter: Merge4_InitialOutput
                                      * Referenced by: '<S4>/Merge4'
                                      */
  real_T Merge5_InitialOutput;       /* Computed Parameter: Merge5_InitialOutput
                                      * Referenced by: '<S4>/Merge5'
                                      */
  uint16_T Constant_Value_m;           /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S12>/Constant'
                                        */
  uint16_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S12>/Unit Delay'
                                */
  uint16_T Merge_InitialOutput_m;   /* Computed Parameter: Merge_InitialOutput_m
                                     * Referenced by: '<S12>/Merge'
                                     */
  P_Frente_mini_car_ble_T Re;          /* '<S4>/Re' */
  P_Frente_mini_car_ble_T Frente;      /* '<S4>/Frente' */
  P_SpeedMode1_mini_car_ble_T SpeedMode3;/* '<S12>/Speed Mode 3' */
  P_SpeedMode1_mini_car_ble_T SpeedMode2;/* '<S12>/Speed Mode 2' */
  P_SpeedMode1_mini_car_ble_T SpeedMode1;/* '<S12>/Speed Mode 1' */
  P_IfActionSubsystem_mini_car__T IfActionSubsystem2;/* '<S2>/If Action Subsystem2' */
  P_IfActionSubsystem_mini_car__T IfActionSubsystem1;/* '<S2>/If Action Subsystem1' */
  P_IfActionSubsystem_mini_car__T IfActionSubsystem;/* '<S2>/If Action Subsystem' */
};

/* Real-time Model Data Structure */
struct tag_RTM_mini_car_ble_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_mini_car_ble_T mini_car_ble_P;

/* Block signals (default storage) */
extern B_mini_car_ble_T mini_car_ble_B;

/* Block states (default storage) */
extern DW_mini_car_ble_T mini_car_ble_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_mini_car_ble_T mini_car_ble_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_mini_car_ble_T mini_car_ble_Y;

/* Model entry point functions */
extern void mini_car_ble_initialize(void);
extern void mini_car_ble_step(void);
extern void mini_car_ble_terminate(void);

/* Real-time Model object */
extern RT_MODEL_mini_car_ble_T *const mini_car_ble_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'mini_car_ble'
 * '<S1>'   : 'mini_car_ble/Mini Remote Car'
 * '<S2>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed'
 * '<S3>'   : 'mini_car_ble/Mini Remote Car/Magnitude Normalization'
 * '<S4>'   : 'mini_car_ble/Mini Remote Car/Subsystem1'
 * '<S5>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Compare To Constant'
 * '<S6>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Compare To Constant1'
 * '<S7>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Compare To Constant2'
 * '<S8>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Detect Change'
 * '<S9>'   : 'mini_car_ble/Mini Remote Car/ChangeSpeed/If Action Subsystem'
 * '<S10>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/If Action Subsystem1'
 * '<S11>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/If Action Subsystem2'
 * '<S12>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem'
 * '<S13>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant'
 * '<S14>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant1'
 * '<S15>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant2'
 * '<S16>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant3'
 * '<S17>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant4'
 * '<S18>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant5'
 * '<S19>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant6'
 * '<S20>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant7'
 * '<S21>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant8'
 * '<S22>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Compare To Constant9'
 * '<S23>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Speed Mode 1'
 * '<S24>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Speed Mode 2'
 * '<S25>'  : 'mini_car_ble/Mini Remote Car/ChangeSpeed/Subsystem/Speed Mode 3'
 * '<S26>'  : 'mini_car_ble/Mini Remote Car/Magnitude Normalization/Compare To Constant'
 * '<S27>'  : 'mini_car_ble/Mini Remote Car/Magnitude Normalization/Normalize'
 * '<S28>'  : 'mini_car_ble/Mini Remote Car/Magnitude Normalization/Set Zero'
 * '<S29>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Compare To Constant'
 * '<S30>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Compare To Constant1'
 * '<S31>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Compare To Constant2'
 * '<S32>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Compare To Constant3'
 * '<S33>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Frente'
 * '<S34>'  : 'mini_car_ble/Mini Remote Car/Subsystem1/Re'
 */
#endif                                 /* RTW_HEADER_mini_car_ble_h_ */
