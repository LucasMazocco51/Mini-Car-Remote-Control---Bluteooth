/*
 * mini_car_ble_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mini_car_ble".
 *
 * Model version              : 1.17
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Sat May 11 03:00:30 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_mini_car_ble_types_h_
#define RTW_HEADER_mini_car_ble_types_h_

/* Parameters for system: '<S2>/If Action Subsystem' */
typedef struct P_IfActionSubsystem_mini_car__T_ P_IfActionSubsystem_mini_car__T;

/* Parameters for system: '<S12>/Speed Mode 1' */
typedef struct P_SpeedMode1_mini_car_ble_T_ P_SpeedMode1_mini_car_ble_T;

/* Parameters for system: '<S4>/Frente' */
typedef struct P_Frente_mini_car_ble_T_ P_Frente_mini_car_ble_T;

/* Parameters (default storage) */
typedef struct P_mini_car_ble_T_ P_mini_car_ble_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_mini_car_ble_T RT_MODEL_mini_car_ble_T;

#endif                                 /* RTW_HEADER_mini_car_ble_types_h_ */
