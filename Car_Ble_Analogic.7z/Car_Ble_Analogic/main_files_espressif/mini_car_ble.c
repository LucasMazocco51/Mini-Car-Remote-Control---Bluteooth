/*
 * mini_car_ble.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "mini_car_ble".
 *
 * Model version              : 1.17
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Sat May 11 03:00:30 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "mini_car_ble.h"
#include "rtwtypes.h"
#include "mini_car_ble_private.h"
#include <math.h>
#include <string.h>
#include "rt_nonfinite.h"

/* Block signals (default storage) */
B_mini_car_ble_T mini_car_ble_B;

/* Block states (default storage) */
DW_mini_car_ble_T mini_car_ble_DW;

/* External inputs (root inport signals with default storage) */
ExtU_mini_car_ble_T mini_car_ble_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_mini_car_ble_T mini_car_ble_Y;

/* Real-time model */
static RT_MODEL_mini_car_ble_T mini_car_ble_M_;
RT_MODEL_mini_car_ble_T *const mini_car_ble_M = &mini_car_ble_M_;
real_T look1_binlcpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = 0.0;
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;

    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = 1.0;
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

/*
 * Output and update for action system:
 *    '<S2>/If Action Subsystem'
 *    '<S2>/If Action Subsystem1'
 *    '<S2>/If Action Subsystem2'
 */
void mini_car_ble_IfActionSubsystem(real_T *rty_Out1,
  P_IfActionSubsystem_mini_car__T *localP)
{
  /* SignalConversion generated from: '<S9>/Out1' incorporates:
   *  Constant: '<S9>/Constant'
   */
  *rty_Out1 = localP->Constant_Value;
}

/*
 * Output and update for action system:
 *    '<S12>/Speed Mode 1'
 *    '<S12>/Speed Mode 2'
 *    '<S12>/Speed Mode 3'
 */
void mini_car_ble_SpeedMode1(uint16_T *rty_Out1, P_SpeedMode1_mini_car_ble_T
  *localP)
{
  /* SignalConversion generated from: '<S23>/Out1' incorporates:
   *  Constant: '<S23>/Constant'
   */
  *rty_Out1 = localP->Constant_Value;
}

/*
 * Output and update for action system:
 *    '<S4>/Frente'
 *    '<S4>/Re'
 */
void mini_car_ble_Frente(real_T *rty_IN1_RMotor, real_T *rty_IN2_RMotor, real_T *
  rty_IN3_LMotor, real_T *rty_IN4_LMotor, P_Frente_mini_car_ble_T *localP)
{
  /* SignalConversion generated from: '<S33>/IN1_RMotor' incorporates:
   *  Constant: '<S33>/Constant'
   */
  *rty_IN1_RMotor = localP->Constant_Value;

  /* SignalConversion generated from: '<S33>/IN3_LMotor' incorporates:
   *  Constant: '<S33>/Constant'
   */
  *rty_IN3_LMotor = localP->Constant_Value;

  /* SignalConversion generated from: '<S33>/IN2_RMotor' incorporates:
   *  Constant: '<S33>/Constant1'
   */
  *rty_IN2_RMotor = localP->Constant1_Value;

  /* SignalConversion generated from: '<S33>/IN4_LMotor' incorporates:
   *  Constant: '<S33>/Constant1'
   */
  *rty_IN4_LMotor = localP->Constant1_Value;
}

/* Model step function */
void mini_car_ble_step(void)
{
  real_T rtb_Merge;
  real_T rtb_Merge1;
  uint16_T rtb_Sum;

  /* Outputs for Enabled SubSystem: '<S2>/Subsystem' incorporates:
   *  EnablePort: '<S12>/Enable'
   */
  /* RelationalOperator: '<S8>/FixPt Relational Operator' incorporates:
   *  Inport: '<Root>/rx_set_speed'
   *  UnitDelay: '<S8>/Delay Input1'
   */
  if (mini_car_ble_U.rx_set_speed != mini_car_ble_DW.DelayInput1_DSTATE) {
    /* Sum: '<S12>/Sum' incorporates:
     *  Constant: '<S12>/Constant'
     *  UnitDelay: '<S12>/Unit Delay'
     */
    rtb_Sum = (uint16_T)(mini_car_ble_P.Constant_Value_m +
                         mini_car_ble_DW.UnitDelay_DSTATE);

    /* If: '<S12>/If' incorporates:
     *  Constant: '<S13>/Constant'
     *  Constant: '<S14>/Constant'
     *  Constant: '<S15>/Constant'
     *  Constant: '<S16>/Constant'
     *  Constant: '<S17>/Constant'
     *  Constant: '<S18>/Constant'
     *  Constant: '<S19>/Constant'
     *  Constant: '<S20>/Constant'
     *  Constant: '<S21>/Constant'
     *  Constant: '<S22>/Constant'
     *  Logic: '<S12>/AND'
     *  Logic: '<S12>/AND1'
     *  Logic: '<S12>/AND2'
     *  Logic: '<S12>/AND3'
     *  Logic: '<S12>/AND4'
     *  Logic: '<S12>/OR'
     *  Logic: '<S12>/OR1'
     *  RelationalOperator: '<S13>/Compare'
     *  RelationalOperator: '<S14>/Compare'
     *  RelationalOperator: '<S15>/Compare'
     *  RelationalOperator: '<S16>/Compare'
     *  RelationalOperator: '<S17>/Compare'
     *  RelationalOperator: '<S18>/Compare'
     *  RelationalOperator: '<S19>/Compare'
     *  RelationalOperator: '<S20>/Compare'
     *  RelationalOperator: '<S21>/Compare'
     *  RelationalOperator: '<S22>/Compare'
     */
    if (((mini_car_ble_U.rx_set_speed ==
          mini_car_ble_P.CompareToConstant_const_a) && (rtb_Sum ==
          mini_car_ble_P.CompareToConstant1_const_i)) ||
        ((mini_car_ble_U.rx_set_speed ==
          mini_car_ble_P.CompareToConstant2_const_c) && (rtb_Sum ==
          mini_car_ble_P.CompareToConstant3_const_g))) {
      /* Outputs for IfAction SubSystem: '<S12>/Speed Mode 1' incorporates:
       *  ActionPort: '<S23>/Action Port'
       */
      mini_car_ble_SpeedMode1(&mini_car_ble_B.Merge_d,
        &mini_car_ble_P.SpeedMode1);

      /* End of Outputs for SubSystem: '<S12>/Speed Mode 1' */
    } else if (((mini_car_ble_U.rx_set_speed ==
                 mini_car_ble_P.CompareToConstant4_const) && (rtb_Sum ==
                 mini_car_ble_P.CompareToConstant5_const)) ||
               ((mini_car_ble_U.rx_set_speed ==
                 mini_car_ble_P.CompareToConstant6_const) && (rtb_Sum ==
                 mini_car_ble_P.CompareToConstant7_const))) {
      /* Outputs for IfAction SubSystem: '<S12>/Speed Mode 2' incorporates:
       *  ActionPort: '<S24>/Action Port'
       */
      mini_car_ble_SpeedMode1(&mini_car_ble_B.Merge_d,
        &mini_car_ble_P.SpeedMode2);

      /* End of Outputs for SubSystem: '<S12>/Speed Mode 2' */
    } else if ((mini_car_ble_U.rx_set_speed ==
                mini_car_ble_P.CompareToConstant8_const) && (rtb_Sum ==
                mini_car_ble_P.CompareToConstant9_const)) {
      /* Outputs for IfAction SubSystem: '<S12>/Speed Mode 3' incorporates:
       *  ActionPort: '<S25>/Action Port'
       */
      mini_car_ble_SpeedMode1(&mini_car_ble_B.Merge_d,
        &mini_car_ble_P.SpeedMode3);

      /* End of Outputs for SubSystem: '<S12>/Speed Mode 3' */
    }

    /* End of If: '<S12>/If' */

    /* Update for UnitDelay: '<S12>/Unit Delay' */
    mini_car_ble_DW.UnitDelay_DSTATE = mini_car_ble_B.Merge_d;
  }

  /* End of RelationalOperator: '<S8>/FixPt Relational Operator' */
  /* End of Outputs for SubSystem: '<S2>/Subsystem' */

  /* If: '<S2>/If' incorporates:
   *  Constant: '<S5>/Constant'
   *  Constant: '<S6>/Constant'
   *  Constant: '<S7>/Constant'
   *  RelationalOperator: '<S5>/Compare'
   *  RelationalOperator: '<S6>/Compare'
   *  RelationalOperator: '<S7>/Compare'
   */
  if (mini_car_ble_B.Merge_d == mini_car_ble_P.CompareToConstant_const_n) {
    /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem' incorporates:
     *  ActionPort: '<S9>/Action Port'
     */
    mini_car_ble_IfActionSubsystem(&mini_car_ble_B.Merge,
      &mini_car_ble_P.IfActionSubsystem);

    /* End of Outputs for SubSystem: '<S2>/If Action Subsystem' */
  } else if (mini_car_ble_B.Merge_d == mini_car_ble_P.CompareToConstant1_const_n)
  {
    /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S10>/Action Port'
     */
    mini_car_ble_IfActionSubsystem(&mini_car_ble_B.Merge,
      &mini_car_ble_P.IfActionSubsystem1);

    /* End of Outputs for SubSystem: '<S2>/If Action Subsystem1' */
  } else if (mini_car_ble_B.Merge_d == mini_car_ble_P.CompareToConstant2_const_a)
  {
    /* Outputs for IfAction SubSystem: '<S2>/If Action Subsystem2' incorporates:
     *  ActionPort: '<S11>/Action Port'
     */
    mini_car_ble_IfActionSubsystem(&mini_car_ble_B.Merge,
      &mini_car_ble_P.IfActionSubsystem2);

    /* End of Outputs for SubSystem: '<S2>/If Action Subsystem2' */
  }

  /* End of If: '<S2>/If' */

  /* If: '<S3>/If' incorporates:
   *  Constant: '<S26>/Constant'
   *  DataTypeConversion: '<S3>/Cast'
   *  Inport: '<Root>/rx_directionStatus'
   *  RelationalOperator: '<S26>/Compare'
   */
  if (mini_car_ble_U.rx_directionStatus ==
      mini_car_ble_P.CompareToConstant_const) {
    /* Outputs for IfAction SubSystem: '<S3>/Set Zero' incorporates:
     *  ActionPort: '<S28>/Action Port'
     */
    /* SignalConversion generated from: '<S28>/Out1' incorporates:
     *  Constant: '<S28>/Constant'
     */
    rtb_Merge = mini_car_ble_P.Constant_Value;

    /* SignalConversion generated from: '<S28>/Output' incorporates:
     *  Constant: '<S28>/Constant'
     */
    rtb_Merge1 = mini_car_ble_P.Constant_Value;

    /* End of Outputs for SubSystem: '<S3>/Set Zero' */
  } else {
    /* Outputs for IfAction SubSystem: '<S3>/Normalize' incorporates:
     *  ActionPort: '<S27>/Action Port'
     */
    /* Product: '<S27>/Product' incorporates:
     *  DataTypeConversion: '<S27>/Cast'
     *  Lookup_n-D: '<S27>/Motor A'
     */
    rtb_Merge = mini_car_ble_B.Merge * look1_binlcpw
      (mini_car_ble_U.rx_directionStatus, mini_car_ble_P.MotorA_bp01Data,
       mini_car_ble_P.MotorA_tableData, 4U);

    /* Product: '<S27>/Product1' incorporates:
     *  DataTypeConversion: '<S27>/Cast'
     *  Lookup_n-D: '<S27>/Motor B'
     */
    rtb_Merge1 = mini_car_ble_B.Merge * look1_binlcpw
      (mini_car_ble_U.rx_directionStatus, mini_car_ble_P.MotorB_bp01Data,
       mini_car_ble_P.MotorB_tableData, 4U);

    /* End of Outputs for SubSystem: '<S3>/Normalize' */
  }

  /* End of If: '<S3>/If' */

  /* Outport: '<Root>/Drive_RMotor' incorporates:
   *  Abs: '<S1>/Abs'
   */
  mini_car_ble_Y.Drive_RMotor = fabs(rtb_Merge);

  /* Outport: '<Root>/Drive_LMotor' incorporates:
   *  Abs: '<S1>/Abs1'
   */
  mini_car_ble_Y.Drive_LMotor = fabs(rtb_Merge1);

  /* If: '<S4>/If' incorporates:
   *  Constant: '<S29>/Constant'
   *  Constant: '<S30>/Constant'
   *  Constant: '<S31>/Constant'
   *  Constant: '<S32>/Constant'
   *  Logic: '<S4>/AND'
   *  Logic: '<S4>/AND1'
   *  RelationalOperator: '<S29>/Compare'
   *  RelationalOperator: '<S30>/Compare'
   *  RelationalOperator: '<S31>/Compare'
   *  RelationalOperator: '<S32>/Compare'
   */
  if ((rtb_Merge > mini_car_ble_P.CompareToConstant_const_h) && (rtb_Merge1 >
       mini_car_ble_P.CompareToConstant1_const)) {
    /* Outputs for IfAction SubSystem: '<S4>/Frente' incorporates:
     *  ActionPort: '<S33>/Action Port'
     */
    mini_car_ble_Frente(&mini_car_ble_B.Merge2, &mini_car_ble_B.Merge3,
                        &mini_car_ble_B.Merge4, &mini_car_ble_B.Merge5,
                        &mini_car_ble_P.Frente);

    /* End of Outputs for SubSystem: '<S4>/Frente' */
  } else if ((rtb_Merge < mini_car_ble_P.CompareToConstant2_const) &&
             (rtb_Merge1 < mini_car_ble_P.CompareToConstant3_const)) {
    /* Outputs for IfAction SubSystem: '<S4>/Re' incorporates:
     *  ActionPort: '<S34>/Action Port'
     */
    mini_car_ble_Frente(&mini_car_ble_B.Merge2, &mini_car_ble_B.Merge3,
                        &mini_car_ble_B.Merge4, &mini_car_ble_B.Merge5,
                        &mini_car_ble_P.Re);

    /* End of Outputs for SubSystem: '<S4>/Re' */
  }

  /* End of If: '<S4>/If' */

  /* Outport: '<Root>/IN1_RMotor' */
  mini_car_ble_Y.IN1_RMotor = mini_car_ble_B.Merge2;

  /* Outport: '<Root>/IN2_RMotor' */
  mini_car_ble_Y.IN2_RMotor = mini_car_ble_B.Merge3;

  /* Outport: '<Root>/IN3_LMotor' */
  mini_car_ble_Y.IN3_LMotor = mini_car_ble_B.Merge4;

  /* Outport: '<Root>/IN4_LMotor' */
  mini_car_ble_Y.IN4_LMotor = mini_car_ble_B.Merge5;

  /* Update for UnitDelay: '<S8>/Delay Input1' incorporates:
   *  Inport: '<Root>/rx_set_speed'
   */
  mini_car_ble_DW.DelayInput1_DSTATE = mini_car_ble_U.rx_set_speed;

  /* Matfile logging */
  rt_UpdateTXYLogVars(mini_car_ble_M->rtwLogInfo,
                      (&mini_car_ble_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.2s, 0.0s] */
    if ((rtmGetTFinal(mini_car_ble_M)!=-1) &&
        !((rtmGetTFinal(mini_car_ble_M)-mini_car_ble_M->Timing.taskTime0) >
          mini_car_ble_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(mini_car_ble_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++mini_car_ble_M->Timing.clockTick0)) {
    ++mini_car_ble_M->Timing.clockTickH0;
  }

  mini_car_ble_M->Timing.taskTime0 = mini_car_ble_M->Timing.clockTick0 *
    mini_car_ble_M->Timing.stepSize0 + mini_car_ble_M->Timing.clockTickH0 *
    mini_car_ble_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void mini_car_ble_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)mini_car_ble_M, 0,
                sizeof(RT_MODEL_mini_car_ble_T));
  rtmSetTFinal(mini_car_ble_M, -1);
  mini_car_ble_M->Timing.stepSize0 = 0.2;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    mini_car_ble_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(mini_car_ble_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(mini_car_ble_M->rtwLogInfo, (NULL));
    rtliSetLogT(mini_car_ble_M->rtwLogInfo, "tout");
    rtliSetLogX(mini_car_ble_M->rtwLogInfo, "");
    rtliSetLogXFinal(mini_car_ble_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(mini_car_ble_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(mini_car_ble_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(mini_car_ble_M->rtwLogInfo, 0);
    rtliSetLogDecimation(mini_car_ble_M->rtwLogInfo, 1);
    rtliSetLogY(mini_car_ble_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(mini_car_ble_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(mini_car_ble_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &mini_car_ble_B), 0,
                sizeof(B_mini_car_ble_T));

  /* states (dwork) */
  (void) memset((void *)&mini_car_ble_DW, 0,
                sizeof(DW_mini_car_ble_T));

  /* external inputs */
  (void)memset(&mini_car_ble_U, 0, sizeof(ExtU_mini_car_ble_T));

  /* external outputs */
  (void)memset(&mini_car_ble_Y, 0, sizeof(ExtY_mini_car_ble_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(mini_car_ble_M->rtwLogInfo, 0.0, rtmGetTFinal
    (mini_car_ble_M), mini_car_ble_M->Timing.stepSize0, (&rtmGetErrorStatus
    (mini_car_ble_M)));

  /* InitializeConditions for UnitDelay: '<S8>/Delay Input1' */
  mini_car_ble_DW.DelayInput1_DSTATE = mini_car_ble_P.DetectChange_vinit;

  /* SystemInitialize for Enabled SubSystem: '<S2>/Subsystem' */
  /* InitializeConditions for UnitDelay: '<S12>/Unit Delay' */
  mini_car_ble_DW.UnitDelay_DSTATE = mini_car_ble_P.UnitDelay_InitialCondition;

  /* SystemInitialize for Merge: '<S12>/Merge' */
  mini_car_ble_B.Merge_d = mini_car_ble_P.Merge_InitialOutput_m;

  /* End of SystemInitialize for SubSystem: '<S2>/Subsystem' */

  /* SystemInitialize for Merge: '<S2>/Merge' */
  mini_car_ble_B.Merge = mini_car_ble_P.Merge_InitialOutput;

  /* SystemInitialize for Merge: '<S4>/Merge2' */
  mini_car_ble_B.Merge2 = mini_car_ble_P.Merge2_InitialOutput;

  /* SystemInitialize for Merge: '<S4>/Merge3' */
  mini_car_ble_B.Merge3 = mini_car_ble_P.Merge3_InitialOutput;

  /* SystemInitialize for Merge: '<S4>/Merge4' */
  mini_car_ble_B.Merge4 = mini_car_ble_P.Merge4_InitialOutput;

  /* SystemInitialize for Merge: '<S4>/Merge5' */
  mini_car_ble_B.Merge5 = mini_car_ble_P.Merge5_InitialOutput;
}

/* Model terminate function */
void mini_car_ble_terminate(void)
{
  /* (no terminate code required) */
}
